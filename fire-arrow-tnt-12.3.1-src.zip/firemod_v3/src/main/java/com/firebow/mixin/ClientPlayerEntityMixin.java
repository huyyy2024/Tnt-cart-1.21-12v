package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import com.firebow.target.PlacementTarget;
import com.firebow.util.BowTrajectoryUtil;
import com.firebow.util.InteractionUtil;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Unique private boolean firebow$wasUsingBow = false;
    @Unique private int     firebow$useTimeLeft  = 0;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void firebow$beforeSync(CallbackInfo ci) {
        FireBowRuntime.get().beforeSync();
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void firebow$onTick(CallbackInfo ci) {
        FireBowRuntime rt = FireBowRuntime.get();
        if (!rt.isEnabled()) return;

        ClientPlayerEntity self = (ClientPlayerEntity)(Object) this;
        boolean usingBow = self.isUsingItem() && BowTrajectoryUtil.isHoldingBow(self);

        if (usingBow) {
            firebow$wasUsingBow = true;
            firebow$useTimeLeft = self.getItemUseTimeLeft();
        } else if (firebow$wasUsingBow) {
            firebow$wasUsingBow = false;
            onBowRelease(self, rt, firebow$useTimeLeft);
            firebow$useTimeLeft = 0;
        }
    }

    @Unique
    private void onBowRelease(ClientPlayerEntity player, FireBowRuntime rt, int useTimeLeft) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.interactionManager == null) return;

        // Suppress FireArrowMixin TRƯỚC KHI predict
        // Đảm bảo arrow tick không chạy song song dù predict thành công hay thất bại
        rt.suppressArrowMixin();

        BlockPos railPos = BowTrajectoryUtil.predictLanding(player, useTimeLeft);
        if (railPos == null) return;
        if (!InteractionUtil.inReach(player, railPos)) return;

        // Khoảng cách tối thiểu 1 block
        if (player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(railPos)) < 1.0) return;

        // Check inventory
        PlacementTarget target = PlacementTarget.tryCreate(railPos);
        if (target == null) return;

        // Lên lịch rail sau 1 tick — arrow packet kịp gửi trước
        // Tránh slot switch cancel bow draw
        long ping = 50L;
        try {
            if (mc.getNetworkHandler() != null) {
                var e = mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
                if (e != null) ping = e.getLatency();
            }
        } catch (Exception ignored) {}

        int cartDelay = ping > 200 ? 3 : ping > 100 ? 2 : 1;
        rt.scheduleBowRelease(railPos, cartDelay);
    }
}
